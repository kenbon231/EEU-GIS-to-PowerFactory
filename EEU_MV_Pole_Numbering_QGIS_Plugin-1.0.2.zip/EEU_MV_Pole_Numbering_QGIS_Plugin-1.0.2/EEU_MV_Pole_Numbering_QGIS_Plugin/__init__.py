def classFactory(iface):
    from .eeu_pole_numbering import EEUPoleNumberingPlugin
    return EEUPoleNumberingPlugin(iface)
