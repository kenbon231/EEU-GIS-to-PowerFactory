# EEU MV Pole Numbering

A QGIS plugin for numbering medium-voltage (MV) pole features from the pole nearest to a selected substation.

## Features
- Select MV pole, MV overhead line, and substation point layers.
- Optionally filter overhead lines by a feeder field and feeder value.
- Set a snapping tolerance.
- Write a GeoPackage output layer named `Numbered_Poles`.
- Preserve original pole attributes and add `Pole_No`, `Pole_Seq`, `Distance_m`, and `Network_Status`.

## Before publishing
Replace the maintainer email in `metadata.txt` with a real monitored email address. Test the plugin in QGIS before publishing.
