import os
import math
import heapq
from collections import defaultdict

from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QFormLayout, QComboBox, QDoubleSpinBox,
    QLineEdit, QPushButton, QLabel, QFileDialog, QMessageBox
)
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsFeature, QgsFields, QgsField,
    QgsGeometry, QgsPointXY, QgsVectorFileWriter, QgsCoordinateTransform
)


class EEUPoleNumberingPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        self.action = QAction("EEU MV Pole Numbering", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&EEU GIS Tools", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&EEU GIS Tools", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        dlg = PoleNumberingDialog(self.iface)
        dlg.exec_()


class PoleNumberingDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("EEU MV Pole Numbering")
        self.resize(520, 310)
        layout = QVBoxLayout(self)
        info = QLabel(
            "Numbers poles starting at the pole nearest to the selected substation. "
            "All pole features are retained, including poles not connected to MV lines."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        form = QFormLayout()
        self.poles_combo, self.lines_combo, self.sub_combo = QComboBox(), QComboBox(), QComboBox()
        for layer in QgsProject.instance().mapLayers().values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            geom = layer.geometryType()
            if geom == QgsWkbTypes.PointGeometry:
                self.poles_combo.addItem(layer.name(), layer.id())
                self.sub_combo.addItem(layer.name(), layer.id())
            elif geom == QgsWkbTypes.LineGeometry:
                self.lines_combo.addItem(layer.name(), layer.id())
        form.addRow("MV Pole point layer:", self.poles_combo)
        form.addRow("MV Overhead line layer:", self.lines_combo)
        form.addRow("Substation point layer:", self.sub_combo)
        self.feeder_field = QLineEdit("Feeder_Name")
        self.feeder_value = QLineEdit()
        self.tolerance = QDoubleSpinBox()
        self.tolerance.setDecimals(2)
        self.tolerance.setRange(0.1, 100.0)
        self.tolerance.setValue(5.0)
        self.tolerance.setSuffix(" map units")
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Choose output GeoPackage path")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self.browse_output)
        outrow = QVBoxLayout()
        outrow.addWidget(self.output_edit)
        outrow.addWidget(browse)
        form.addRow("Feeder field on lines:", self.feeder_field)
        form.addRow("Feeder value (optional):", self.feeder_value)
        form.addRow("Snap tolerance:", self.tolerance)
        layout.addLayout(form)
        layout.addWidget(QLabel("Output:"))
        layout.addLayout(outrow)
        self.run_button = QPushButton("Create numbered pole layer")
        self.run_button.clicked.connect(self.process)
        layout.addWidget(self.run_button)

    def browse_output(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save numbered poles", "", "GeoPackage (*.gpkg)")
        if path:
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            self.output_edit.setText(path)

    def layer_by_combo(self, combo):
        layer_id = combo.currentData()
        return QgsProject.instance().mapLayer(layer_id) if layer_id else None

    def process(self):
        poles, lines, subs = (self.layer_by_combo(c) for c in
                              (self.poles_combo, self.lines_combo, self.sub_combo))
        outpath = self.output_edit.text().strip()
        if not poles or not lines or not subs:
            QMessageBox.warning(self, "Missing input", "Choose pole, MV overhead line, and substation layers.")
            return
        if poles.id() == subs.id():
            QMessageBox.warning(self, "Invalid inputs", "Choose a separate substation layer.")
            return
        if not outpath:
            QMessageBox.warning(self, "Output required", "Choose an output GeoPackage path.")
            return
        if any(layer.crs().isGeographic() for layer in (poles, lines, subs)):
            QMessageBox.warning(self, "CRS required", "All inputs must use projected coordinate systems with metre units.")
            return
        try:
            self.run_button.setEnabled(False)
            self.create_numbering(poles, lines, subs, outpath)
            QMessageBox.information(self, "Finished", "Pole numbering completed. Output layer added to the QGIS project.")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Processing error", str(e))
        finally:
            self.run_button.setEnabled(True)

    def create_numbering(self, poles, lines, subs, outpath):
        project = QgsProject.instance()
        tolerance = float(self.tolerance.value())
        feeder_field, feeder_value = self.feeder_field.text().strip(), self.feeder_value.text().strip()
        pole_crs = poles.crs()
        line_transform = QgsCoordinateTransform(lines.crs(), pole_crs, project)
        sub_transform = QgsCoordinateTransform(subs.crs(), pole_crs, project)
        pole_feats = [f for f in poles.getFeatures()
                      if not f.geometry().isNull() and not f.geometry().isEmpty()]
        if not pole_feats:
            raise Exception("The pole layer contains no valid point geometries.")
        sub_geoms = []
        for sf in subs.getFeatures():
            g = QgsGeometry(sf.geometry())
            if g.isNull() or g.isEmpty():
                continue
            g.transform(sub_transform)
            sub_geoms.append(g)
        if not sub_geoms:
            raise Exception("No valid substation geometry was found.")

        nodes, graph = [], defaultdict(list)
        def node_id(pt):
            for i, (x, y) in enumerate(nodes):
                if math.hypot(pt.x() - x, pt.y() - y) <= tolerance:
                    return i
            nodes.append((pt.x(), pt.y()))
            return len(nodes) - 1

        for lf in lines.getFeatures():
            if feeder_value and feeder_field and feeder_field in lf.fields().names():
                if str(lf[feeder_field]).strip().casefold() != feeder_value.casefold():
                    continue
            geom = QgsGeometry(lf.geometry())
            if geom.isNull() or geom.isEmpty():
                continue
            geom.transform(line_transform)
            parts = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
            for part in parts:
                for a, b in zip(part[:-1], part[1:]):
                    pa, pb = QgsPointXY(a), QgsPointXY(b)
                    na, nb = node_id(pa), node_id(pb)
                    if na == nb:
                        continue
                    d = math.hypot(pa.x() - pb.x(), pa.y() - pb.y())
                    graph[na].append((nb, d))
                    graph[nb].append((na, d))

        pole_points, pole_node = {}, {}
        for pf in pole_feats:
            pt = QgsPointXY(pf.geometry().asPoint())
            pole_points[pf.id()] = pt
            best = min(((math.hypot(pt.x()-x, pt.y()-y), i) for i, (x, y) in enumerate(nodes)), default=None)
            if best and best[0] <= tolerance:
                pole_node[pf.id()] = best[1]

        def min_sub_dist(pf):
            pt = pole_points[pf.id()]
            return min(g.distance(QgsGeometry.fromPointXY(pt)) for g in sub_geoms)

        candidates = [pf for pf in pole_feats if pf.id() in pole_node] or pole_feats
        start_feature = min(candidates, key=min_sub_dist)
        start_node = pole_node.get(start_feature.id())
        node_dist = {}
        if start_node is not None:
            node_dist[start_node] = 0.0
            heap = [(0.0, start_node)]
            while heap:
                dist, u = heapq.heappop(heap)
                if dist != node_dist.get(u):
                    continue
                for v, w in graph.get(u, []):
                    nd = dist + w
                    if nd < node_dist.get(v, float("inf")):
                        node_dist[v] = nd
                        heapq.heappush(heap, (nd, v))
        def sort_key(pf):
            nid = pole_node.get(pf.id())
            if nid is not None and nid in node_dist:
                return (0, node_dist[nid], min_sub_dist(pf), pf.id())
            return (1, min_sub_dist(pf), pf.id(), pf.id())
        ordered = sorted(pole_feats, key=sort_key)
        ordered.remove(start_feature)
        ordered.insert(0, start_feature)

        fields = QgsFields()
        for fld in poles.fields():
            fields.append(QgsField(fld))
        existing = {f.name().lower() for f in fields}
        for name, typ, length in [
            ("Pole_No", QVariant.String, 40), ("Pole_Seq", QVariant.Int, 0),
            ("Distance_m", QVariant.Double, 0), ("Network_Status", QVariant.String, 30)
        ]:
            if name.lower() not in existing:
                fields.append(QgsField(name, typ, len=length if length else 0,
                                       prec=3 if typ == QVariant.Double else 0))
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName, options.fileEncoding, options.layerName = "GPKG", "UTF-8", "Numbered_Poles"
        if os.path.exists(outpath):
            os.remove(outpath)
        result = QgsVectorFileWriter.create(outpath, fields, poles.wkbType(), poles.crs(),
                                            project.transformContext(), options)
        writer, err = result[0], result[1]
        if writer is None:
            raise Exception("Could not create output GeoPackage: " + str(err))
        name_idx = next(i for i, f in enumerate(fields) if f.name().lower() == "pole_no")
        seq_idx = next(i for i, f in enumerate(fields) if f.name().lower() == "pole_seq")
        dist_idx = next(i for i, f in enumerate(fields) if f.name().lower() == "distance_m")
        status_idx = next(i for i, f in enumerate(fields) if f.name().lower() == "network_status")
        for seq, pf in enumerate(ordered, start=1):
            newf = QgsFeature(fields)
            newf.setGeometry(pf.geometry())
            out_attrs = list(pf.attributes()) + [None] * (len(fields) - len(pf.attributes()))
            nid = pole_node.get(pf.id())
            if nid is not None and nid in node_dist:
                distance, status = node_dist[nid], "Connected"
            elif nid is not None:
                distance, status = None, "Disconnected"
            else:
                distance, status = None, "Not snapped to MV line"
            out_attrs[name_idx], out_attrs[seq_idx] = "PN_" + str(seq), seq
            out_attrs[dist_idx], out_attrs[status_idx] = distance, status
            newf.setAttributes(out_attrs)
            if not writer.addFeature(newf):
                writer.rollback()
                raise Exception("Failed writing a pole feature to output.")
        del writer
        output_layer = QgsVectorLayer(outpath + "|layername=Numbered_Poles", "EEU Numbered MV Poles", "ogr")
        if not output_layer.isValid():
            raise Exception("Output was written but QGIS could not load the output layer.")
        project.addMapLayer(output_layer)
