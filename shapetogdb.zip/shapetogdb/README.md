# Export Layers to File Geodatabase (.gdb)

A QGIS Processing Toolbox plugin that lets you batch export multiple vector layers (Shapefiles, GeoPackages, Memory layers) directly into an ESRI File Geodatabase (.gdb).

## Features
- Multiple layer selection and batch processing.
- Automatic name sanitation for GDB feature class compatibility.
- Optional on-the-fly CRS reprojection.
- Overwrite controls for existing GDBs and feature classes.
- Full integration with QGIS 3.28+ processing logs and progress bars.