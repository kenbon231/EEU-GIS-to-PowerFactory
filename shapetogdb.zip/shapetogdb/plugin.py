# -*- coding: utf-8 -*-
from qgis.core import QgsApplication
from .provider import ExportLayersToGDBProvider


class ExportLayersToGDBPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initProcessing(self):
        self.provider = ExportLayersToGDBProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        QgsApplication.processingRegistry().removeProvider(self.provider)