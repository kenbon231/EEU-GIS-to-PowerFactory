# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ExportLayersToGDB
                                 A QGIS plugin
 Exports multiple vector layers into an ESRI File Geodatabase (.gdb)
 ***************************************************************************/
"""


def classFactory(iface):
    from .plugin import ExportLayersToGDBPlugin
    return ExportLayersToGDBPlugin(iface)