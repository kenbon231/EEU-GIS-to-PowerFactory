# -*- coding: utf-8 -*-
import os
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsVectorFileWriter,
    QgsCoordinateTransform,
    QgsProject
)


class ExportLayersToGDBAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYERS = 'INPUT_LAYERS'
    GDB_FOLDER = 'GDB_FOLDER'
    GDB_NAME = 'GDB_NAME'
    OVERWRITE = 'OVERWRITE'
    TARGET_CRS = 'TARGET_CRS'

    def name(self):
        return 'export_layers_to_gdb'

    def displayName(self):
        return 'Export Layers to File Geodatabase (.gdb)'

    def group(self):
        return 'Database & Data Conversion'

    def groupId(self):
        return 'db_conversion'

    def shortHelpString(self):
        return (
            "Takes selected input vector layers (Shapefiles, GeoPackages, Memory layers) "
            "and exports them as feature classes into a targeted ESRI File Geodatabase (.gdb)."
        )

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                'Select Input Layers (Shapefiles/Vector layers)'
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.GDB_FOLDER,
                'Output Directory for Geodatabase'
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.GDB_NAME,
                'Geodatabase Name (with or without .gdb)',
                defaultValue='Converted_Network_Data.gdb'
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                'Reproject Target CRS (Optional - leave default for source CRS)',
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.OVERWRITE,
                'Overwrite Existing Geodatabase / Layers',
                defaultValue=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        gdb_folder = self.parameterAsString(parameters, self.GDB_FOLDER, context)
        gdb_name = self.parameterAsString(parameters, self.GDB_NAME, context).strip()
        overwrite = self.parameterAsBool(parameters, self.OVERWRITE, context)
        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)

        if not layers:
            raise RuntimeError("No input layers selected for export.")

        if not gdb_name.lower().endswith('.gdb'):
            gdb_name += '.gdb'

        gdb_path = os.path.join(gdb_folder, gdb_name)
        feedback.pushInfo(f"[+] Target Geodatabase: {gdb_path}")

        os.makedirs(gdb_folder, exist_ok=True)

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "OpenFileGDB"
        options.fileEncoding = "UTF-8"

        transform_context = QgsProject.instance().transformContext()

        count = 0
        total = len(layers)

        for layer in layers:
            if feedback.isCanceled():
                break

            layer_name = layer.name()
            clean_name = "".join([c if c.isalnum() or c == '_' else '_' for c in layer_name])
            options.layerName = clean_name

            if target_crs.isValid():
                options.ct = QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())

            feedback.pushInfo(f"[{count+1}/{total}] Exporting layer '{layer_name}' as feature class '{clean_name}'...")

            if os.path.exists(gdb_path) and count > 0:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
            elif overwrite:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            else:
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

            writer, error_message = QgsVectorFileWriter.writeAsVectorFormatV3(
                layer,
                gdb_path,
                transform_context,
                options
            )

            if writer == QgsVectorFileWriter.NoError:
                feedback.pushInfo(f"  -> Successfully written to {gdb_name}/{clean_name}")
            else:
                feedback.reportError(f"  [!] Failed to write layer {layer_name}: {error_message}")

            count += 1
            feedback.setProgress(int((count / total) * 100))

        feedback.pushInfo(f"[+] Export process complete! File Geodatabase saved at: {gdb_path}")
        return {self.GDB_FOLDER: gdb_path}

    def createInstance(self):
        return ExportLayersToGDBAlgorithm()