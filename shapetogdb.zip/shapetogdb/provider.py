# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .algorithm import ExportLayersToGDBAlgorithm


class ExportLayersToGDBProvider(QgsProcessingProvider):
    def loadAlgorithms(self, *args, **kwargs):
        self.addAlgorithm(ExportLayersToGDBAlgorithm())

    def id(self):
        return 'export_layers_to_gdb_provider'

    def name(self):
        return 'Database & Data Conversion'

    def icon(self):
        return QgsProcessingProvider.icon(self)